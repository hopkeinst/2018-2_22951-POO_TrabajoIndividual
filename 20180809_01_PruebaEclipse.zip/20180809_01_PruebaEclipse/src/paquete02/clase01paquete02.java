package paquete02;

public class clase01paquete02 {
	
	static String cadena = "Hola Paquete02 Clase01";

	public static void main(String[] args) {
		System.out.println(cadena);
	}
}
